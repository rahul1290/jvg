<html>
    <?php if(isset($header)){ print_r($header); } ?>
    <?php print_r($footer); ?>
    <?php print_r($body); ?>
    </body>
</html>