<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $this->config->item('project_title'); ?></title>
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url('assest/');?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url('assest/css/css.css');?>" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url('assest/');?>css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo base_url('assest/');?>css/dataTables.min.css" rel="stylesheet">
    
    <style>
        .haveerror {
            color: red;
            border-color: red;
        }
    </style>
</head>
<input type="hidden" id="baseurl" value="<?php echo base_url();?>" />